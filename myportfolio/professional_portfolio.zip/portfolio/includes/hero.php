<section id="home" class="hero-section d-flex align-items-center">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6" data-aos="fade-right">
                <h5 class="text-primary fw-bold mb-3">Welcome to my Portfolio</h5>
                <h1 class="display-3 fw-bold mb-4">I'm <?php echo $profile['name'] ?? 'John Doe'; ?></h1>
                <h3 class="h4 mb-4 text-secondary"><?php echo $profile['title'] ?? 'Full Stack Developer'; ?></h3>
                <p class="lead mb-5"><?php echo $profile['bio'] ?? 'I build high-quality websites and applications.'; ?></p>
                <div class="hero-btns">
                    <a href="#contact" class="btn btn-primary btn-lg me-3 px-4 py-2">Hire Me</a>
                    <a href="#projects" class="btn btn-outline-light btn-lg px-4 py-2">View Work</a>
                </div>
            </div>
            <div class="col-lg-6 text-center" data-aos="fade-left">
                <div class="hero-img-wrapper">
                    <img src="<?php echo $profile['image'] ? 'uploads/profile/'.$profile['image'] : 'assets/images/default-profile.png'; ?>" alt="Profile" class="img-fluid rounded-circle shadow-lg border border-5 border-primary">
                </div>
            </div>
        </div>
    </div>
</section>
