<?php
require_once 'config.php';

// Get all data from database
$user = getUserData() ?? [];
$services = getAllServices();
$skills = getAllSkills();
$projects = getAllProjects();
$testimonials = getAllTestimonials();
$categories = getAllCategories();

// Set default values if user data not available
$user_name = $user['name'] ?? 'John Doe';
$user_title = $user['title'] ?? 'Creative Web Developer & Designer';
$user_description = $user['description'] ?? 'A Creative Web Developer & Designer passionate about creating beautiful, functional, and user-centered digital experiences.';
$user_about_short = $user['about_content_short'] ?? 'Creative Developer Based in New York';
$user_about_long = $user['about_content_long'] ?? 'I\'m a passionate web developer and designer with over 5 years of experience in creating digital solutions. I specialize in building responsive websites, web applications, and creating stunning user interfaces.';
$user_profile_image = $user['profile_image'] ?? 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=500&h=600&fit=crop';
$user_about_image = $user['about_image'] ?? 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=600&h=700&fit=crop';
$projects_done = $user['projects_done'] ?? 150;
$happy_clients = $user['happy_clients'] ?? 80;
$years_experience = $user['years_experience'] ?? 5;
$user_location = $user['location'] ?? 'New York, NY 10001';
$user_phone = $user['phone'] ?? '+1 (555) 123-4567';
$user_working_hours = $user['working_hours'] ?? 'Mon - Fri: 9AM - 6PM';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Creative Portfolio | <?php echo $user_name; ?></title>
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&family=Playfair+Display:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- AOS Animation Library -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    
    <style>
        :root {
            --primary-color: #6c5ce7;
            --secondary-color: #a29bfe;
            --accent-color: #fd79a8;
            --dark-color: #2d3436;
            --light-color: #f8f9fa;
            --gradient-1: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            --gradient-2: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
            --gradient-3: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
            --gradient-4: linear-gradient(135deg, #43e97b 0%, #38f9d7 100%);
            --gradient-5: linear-gradient(135deg, #fa709a 0%, #fee140 100%);
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', sans-serif;
            overflow-x: hidden;
            background: #0f0f0f;
            color: #fff;
        }
        
        h1, h2, h3, h4, h5, h6 {
            font-family: 'Playfair Display', serif;
        }
        
        /* Custom Scrollbar */
        ::-webkit-scrollbar {
            width: 10px;
        }
        
        ::-webkit-scrollbar-track {
            background: #1a1a1a;
        }
        
        ::-webkit-scrollbar-thumb {
            background: var(--gradient-1);
            border-radius: 5px;
        }
        
        /* Preloader */
        .preloader {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--gradient-1);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 9999;
            transition: opacity 0.5s ease;
        }
        
        .preloader.hidden {
            opacity: 0;
            visibility: hidden;
        }
        
        .loader {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(255,255,255,0.3);
            border-top: 5px solid #fff;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        /* Navigation */
        .navbar {
            background: rgba(15, 15, 15, 0.95);
            backdrop-filter: blur(10px);
            padding: 1rem 0;
            transition: all 0.3s ease;
        }
        
        .navbar.scrolled {
            padding: 0.5rem 0;
            box-shadow: 0 5px 30px rgba(108, 92, 231, 0.3);
        }
        
        .navbar-brand {
            font-family: 'Playfair Display', serif;
            font-size: 1.8rem;
            font-weight: 700;
            background: var(--gradient-5);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .nav-link {
            color: #fff !important;
            font-weight: 500;
            margin: 0 0.5rem;
            position: relative;
            transition: all 0.3s ease;
        }
        
        .nav-link::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--gradient-5);
            transition: width 0.3s ease;
        }
        
        .nav-link:hover::after {
            width: 100%;
        }
        
        .nav-link:hover {
            color: var(--accent-color) !important;
        }
        
        .navbar-toggler {
            border: none;
            background: var(--gradient-1);
        }
        
        .navbar-toggler:focus {
            box-shadow: none;
        }
        
        /* Hero Section */
        .hero {
            min-height: 100vh;
            display: flex;
            align-items: center;
            position: relative;
            background: var(--gradient-1);
            overflow: hidden;
        }
        
        .hero::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.05'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4zm0-30V0h-2v4h-4v2h4v4h2V6h4V4h-4zM6 34v-4H4v4H0v2h4v4h2v-4h4v-2H6zM6 4V0H4v4H0v2h4v4h2V6h4V4H6z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
        }
        
        .hero-content {
            position: relative;
            z-index: 2;
        }
        
        .hero h1 {
            font-size: 4rem;
            font-weight: 700;
            margin-bottom: 1rem;
            line-height: 1.2;
        }
        
        .hero h1 span {
            background: var(--gradient-5);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .hero p {
            font-size: 1.3rem;
            opacity: 0.9;
            margin-bottom: 2rem;
        }
        
        .hero-image {
            position: relative;
            z-index: 2;
        }
        
        .hero-image img {
            width: 100%;
            max-width: 500px;
            border-radius: 20px;
            box-shadow: 0 25px 80px rgba(0,0,0,0.5);
            animation: float 3s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }
        
        .hero-shapes {
            position: absolute;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            overflow: hidden;
            z-index: 1;
        }
        
        .shape {
            position: absolute;
            border-radius: 50%;
            animation: moveShape 20s infinite;
        }
        
        .shape-1 {
            width: 300px;
            height: 300px;
            background: rgba(253, 121, 168, 0.2);
            top: 10%;
            right: 10%;
            animation-delay: 0s;
        }
        
        .shape-2 {
            width: 200px;
            height: 200px;
            background: rgba(79, 172, 254, 0.2);
            bottom: 20%;
            left: 5%;
            animation-delay: 5s;
        }
        
        .shape-3 {
            width: 150px;
            height: 150px;
            background: rgba(67, 233, 123, 0.2);
            top: 50%;
            left: 50%;
            animation-delay: 10s;
        }
        
        @keyframes moveShape {
            0%, 100% { transform: translate(0, 0) rotate(0deg); }
            25% { transform: translate(50px, 50px) rotate(90deg); }
            50% { transform: translate(0, 100px) rotate(180deg); }
            75% { transform: translate(-50px, 50px) rotate(270deg); }
        }
        
        .btn-custom {
            padding: 15px 40px;
            border-radius: 50px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            border: none;
            position: relative;
            overflow: hidden;
            z-index: 1;
        }
        
        .btn-custom::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--gradient-5);
            z-index: -1;
            transition: transform 0.3s ease;
        }
        
        .btn-custom:hover::before {
            transform: scale(1.1);
        }
        
        .btn-custom:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 30px rgba(250, 112, 154, 0.4);
            color: white;
        }
        
        .btn-outline-custom {
            padding: 15px 40px;
            border-radius: 50px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            background: transparent;
            border: 2px solid #fff;
            color: #fff;
        }
        
        .btn-outline-custom:hover {
            background: #fff;
            color: var(--primary-color);
            transform: translateY(-3px);
        }
        
        /* Section Styles */
        section {
            padding: 100px 0;
        }
        
        .section-title {
            text-align: center;
            margin-bottom: 60px;
        }
        
        .section-title h2 {
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 1rem;
            position: relative;
            display: inline-block;
        }
        
        .section-title h2::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: var(--gradient-5);
            border-radius: 2px;
        }
        
        .section-title p {
            color: #aaa;
            font-size: 1.1rem;
            max-width: 600px;
            margin: 20px auto 0;
        }
        
        /* About Section */
        .about {
            background: #1a1a1a;
        }
        
        .about-image {
            position: relative;
        }
        
        .about-image img {
            width: 100%;
            border-radius: 20px;
            box-shadow: 0 25px 80px rgba(0,0,0,0.5);
        }
        
        .about-image::before {
            content: '';
            position: absolute;
            top: -20px;
            left: -20px;
            width: 100px;
            height: 100px;
            background: var(--gradient-2);
            border-radius: 20px;
            z-index: -1;
        }
        
        .about-image::after {
            content: '';
            position: absolute;
            bottom: -20px;
            right: -20px;
            width: 100px;
            height: 100px;
            background: var(--gradient-3);
            border-radius: 20px;
            z-index: -1;
        }
        
        .about-content h3 {
            font-size: 2rem;
            margin-bottom: 1.5rem;
            background: var(--gradient-3);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .about-content p {
            color: #ccc;
            line-height: 1.8;
            margin-bottom: 1.5rem;
        }
        
        .about-stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
            margin-top: 30px;
        }
        
        .stat-item {
            text-align: center;
            padding: 20px;
            background: rgba(255,255,255,0.05);
            border-radius: 15px;
            backdrop-filter: blur(10px);
        }
        
        .stat-item h4 {
            font-size: 2.5rem;
            font-weight: 700;
            background: var(--gradient-4);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .stat-item p {
            color: #aaa;
            font-size: 0.9rem;
            margin: 0;
        }
        
        /* Services Section */
        .services {
            background: #0f0f0f;
        }
        
        .service-card {
            background: rgba(255,255,255,0.05);
            border-radius: 20px;
            padding: 40px 30px;
            text-align: center;
            transition: all 0.3s ease;
            border: 1px solid rgba(255,255,255,0.1);
            position: relative;
            overflow: hidden;
        }
        
        .service-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--gradient-1);
            opacity: 0;
            transition: opacity 0.3s ease;
            z-index: -1;
        }
        
        .service-card:hover::before {
            opacity: 0.1;
        }
        
        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 60px rgba(108, 92, 231, 0.3);
        }
        
        .service-icon {
            width: 80px;
            height: 80px;
            margin: 0 auto 25px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 20px;
            font-size: 2.5rem;
        }
        
        .service-icon-1 { background: var(--gradient-1); }
        .service-icon-2 { background: var(--gradient-2); }
        .service-icon-3 { background: var(--gradient-3); }
        .service-icon-4 { background: var(--gradient-4); }
        .service-icon-5 { background: var(--gradient-5); }
        .service-icon-6 { background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%); }
        
        .service-card h3 {
            font-size: 1.5rem;
            margin-bottom: 15px;
        }
        
        .service-card p {
            color: #aaa;
            line-height: 1.6;
        }
        
        /* Skills Section */
        .skills {
            background: #1a1a1a;
        }
        
        .skill-item {
            margin-bottom: 30px;
        }
        
        .skill-header {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        
        .skill-header h4 {
            font-size: 1.1rem;
            font-weight: 600;
        }
        
        .skill-header span {
            color: var(--accent-color);
            font-weight: 600;
        }
        
        .progress {
            height: 10px;
            background: rgba(255,255,255,0.1);
            border-radius: 10px;
            overflow: hidden;
        }
        
        .progress-bar {
            background: var(--gradient-1);
            border-radius: 10px;
            position: relative;
        }
        
        .progress-bar::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(90deg, transparent, rgba(255,255,255,0.3), transparent);
            animation: shimmer 2s infinite;
        }
        
        @keyframes shimmer {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }
        
        /* Portfolio Section */
        .portfolio {
            background: #0f0f0f;
        }
        
        .portfolio-filter {
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            gap: 15px;
            margin-bottom: 40px;
        }
        
        .filter-btn {
            padding: 10px 25px;
            border: none;
            background: rgba(255,255,255,0.1);
            color: #fff;
            border-radius: 30px;
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .filter-btn:hover,
        .filter-btn.active {
            background: var(--gradient-1);
            transform: translateY(-3px);
        }
        
        .portfolio-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 30px;
        }
        
        .portfolio-item {
            position: relative;
            border-radius: 20px;
            overflow: hidden;
            cursor: pointer;
            aspect-ratio: 4/3;
        }
        
        .portfolio-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }
        
        .portfolio-item:hover img {
            transform: scale(1.1);
        }
        
        .portfolio-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--gradient-1);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            opacity: 0;
            transition: opacity 0.3s ease;
            padding: 20px;
            text-align: center;
        }
        
        .portfolio-item:hover .portfolio-overlay {
            opacity: 1;
        }
        
        .portfolio-overlay h3 {
            font-size: 1.5rem;
            margin-bottom: 10px;
            transform: translateY(20px);
            transition: transform 0.3s ease;
        }
        
        .portfolio-overlay p {
            transform: translateY(20px);
            transition: transform 0.3s ease 0.1s;
        }
        
        .portfolio-item:hover .portfolio-overlay h3,
        .portfolio-item:hover .portfolio-overlay p {
            transform: translateY(0);
        }
        
        .portfolio-overlay .links {
            margin-top: 20px;
            transform: translateY(20px);
            transition: transform 0.3s ease 0.2s;
        }
        
        .portfolio-item:hover .portfolio-overlay .links {
            transform: translateY(0);
        }
        
        .portfolio-overlay .links a {
            color: #fff;
            font-size: 1.5rem;
            margin: 0 10px;
            transition: transform 0.3s ease;
            display: inline-block;
        }
        
        .portfolio-overlay .links a:hover {
            transform: scale(1.2);
        }
        
        /* Testimonials Section */
        .testimonials {
            background: #1a1a1a;
        }
        
        .testimonial-card {
            background: rgba(255,255,255,0.05);
            border-radius: 20px;
            padding: 40px;
            position: relative;
            border: 1px solid rgba(255,255,255,0.1);
        }
        
        .testimonial-card::before {
            content: '"';
            position: absolute;
            top: 20px;
            left: 30px;
            font-size: 5rem;
            font-family: 'Playfair Display', serif;
            background: var(--gradient-1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            line-height: 1;
        }
        
        .testimonial-content {
            position: relative;
            z-index: 1;
        }
        
        .testimonial-content p {
            color: #ccc;
            line-height: 1.8;
            font-style: italic;
            margin-bottom: 25px;
        }
        
        .testimonial-author {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .testimonial-author img {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid var(--accent-color);
        }
        
        .testimonial-author h4 {
            font-size: 1.1rem;
            margin-bottom: 5px;
        }
        
        .testimonial-author span {
            color: var(--accent-color);
            font-size: 0.9rem;
        }
        
        .testimonial-stars {
            color: #ffd700;
            margin-bottom: 15px;
        }
        
        /* Contact Section */
        .contact {
            background: #0f0f0f;
        }
        
        .contact-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-bottom: 50px;
        }
        
        .contact-item {
            background: rgba(255,255,255,0.05);
            border-radius: 20px;
            padding: 30px;
            text-align: center;
            transition: all 0.3s ease;
            border: 1px solid rgba(255,255,255,0.1);
        }
        
        .contact-item:hover {
            transform: translateY(-10px);
            background: rgba(255,255,255,0.1);
        }
        
        .contact-item i {
            font-size: 2.5rem;
            margin-bottom: 20px;
            background: var(--gradient-1);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .contact-item h4 {
            font-size: 1.2rem;
            margin-bottom: 10px;
        }
        
        .contact-item p {
            color: #aaa;
            margin: 0;
        }
        
        .contact-form {
            background: rgba(255,255,255,0.05);
            border-radius: 20px;
            padding: 40px;
            border: 1px solid rgba(255,255,255,0.1);
        }
        
        .form-control {
            background: rgba(255,255,255,0.1);
            border: 1px solid rgba(255,255,255,0.2);
            color: #fff;
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        
        .form-control:focus {
            background: rgba(255,255,255,0.15);
            border-color: var(--accent-color);
            box-shadow: 0 0 20px rgba(253, 121, 168, 0.3);
            color: #fff;
        }
        
        .form-control::placeholder {
            color: #888;
        }
        
        textarea.form-control {
            min-height: 150px;
            resize: none;
        }
        
        /* Footer */
        footer {
            background: #0a0a0a;
            padding: 50px 0 30px;
        }
        
        .footer-content {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 40px;
            margin-bottom: 40px;
        }
        
        .footer-about h3 {
            font-size: 1.8rem;
            margin-bottom: 20px;
            background: var(--gradient-5);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }
        
        .footer-about p {
            color: #aaa;
            line-height: 1.8;
        }
        
        .footer-social {
            display: flex;
            gap: 15px;
            margin-top: 20px;
        }
        
        .footer-social a {
            width: 45px;
            height: 45px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            background: rgba(255,255,255,0.1);
            color: #fff;
            font-size: 1.2rem;
            transition: all 0.3s ease;
        }
        
        .footer-social a:hover {
            background: var(--gradient-1);
            transform: translateY(-5px);
        }
        
        .footer-links h4 {
            font-size: 1.3rem;
            margin-bottom: 20px;
        }
        
        .footer-links ul {
            list-style: none;
            padding: 0;
        }
        
        .footer-links li {
            margin-bottom: 12px;
        }
        
        .footer-links a {
            color: #aaa;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .footer-links a:hover {
            color: var(--accent-color);
            padding-left: 10px;
        }
        
        .footer-bottom {
            text-align: center;
            padding-top: 30px;
            border-top: 1px solid rgba(255,255,255,0.1);
        }
        
        .footer-bottom p {
            color: #666;
            margin: 0;
        }
        
        /* Back to Top Button */
        .back-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background: var(--gradient-1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: #fff;
            font-size: 1.5rem;
            cursor: pointer;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
            z-index: 999;
            border: none;
        }
        
        .back-to-top.visible {
            opacity: 1;
            visibility: visible;
        }
        
        .back-to-top:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(108, 92, 231, 0.5);
        }
        
        /* Responsive Styles */
        @media (max-width: 991px) {
            .hero h1 {
                font-size: 3rem;
            }
            
            .hero-image {
                margin-top: 50px;
            }
            
            .section-title h2 {
                font-size: 2.5rem;
            }
            
            .about-stats {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        
        @media (max-width: 767px) {
            .hero h1 {
                font-size: 2.5rem;
            }
            
            .hero p {
                font-size: 1.1rem;
            }
            
            .section-title h2 {
                font-size: 2rem;
            }
            
            .about-stats {
                grid-template-columns: 1fr;
            }
            
            .portfolio-grid {
                grid-template-columns: 1fr;
            }
            
            .navbar-brand {
                font-size: 1.5rem;
            }
        }
        
        @media (max-width: 575px) {
            .hero h1 {
                font-size: 2rem;
            }
            
            .btn-custom,
            .btn-outline-custom {
                padding: 12px 30px;
                font-size: 0.9rem;
            }
            
            section {
                padding: 60px 0;
            }
        }
        
        /* Animation Classes */
        .fade-in {
            opacity: 0;
            transform: translateY(30px);
            transition: all 0.6s ease;
        }
        
        .fade-in.visible {
            opacity: 1;
            transform: translateY(0);
        }
    </style>
</head>
<body>
    <!-- Preloader -->
    <div class="preloader" id="preloader">
        <div class="loader"></div>
    </div>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark sticky-top">
        <div class="container">
            <a class="navbar-brand" href="#">Portfolio</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="#home">Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#about">About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#services">Services</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#skills">Skills</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#portfolio">Portfolio</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#testimonials">Testimonials</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#contact">Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <section class="hero" id="home">
        <div class="hero-shapes">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
            <div class="shape shape-3"></div>
        </div>
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 hero-content" data-aos="fade-right">
                    <h1>Hi, I'm <span><?php echo $user_name; ?></span></h1>
                    <p><?php echo $user_description; ?></p>
                    <div class="d-flex gap-3 flex-wrap">
                        <a href="#portfolio" class="btn btn-custom">View My Work</a>
                        <a href="#contact" class="btn btn-outline-custom">Contact Me</a>
                    </div>
                </div>
                <div class="col-lg-6 hero-image" data-aos="fade-left">
                    <img src="<?php echo $user_profile_image; ?>" alt="Profile">
                </div>
            </div>
        </div>
    </section>

    <!-- About Section -->
    <section class="about" id="about">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>About Me</h2>
                <p>Get to know more about me and my journey</p>
            </div>
            <div class="row align-items-center">
                <div class="col-lg-6 about-image mb-4 mb-lg-0" data-aos="fade-right">
                    <img src="<?php echo $user_about_image; ?>" alt="About">
                </div>
                <div class="col-lg-6 about-content" data-aos="fade-left">
                    <h3><?php echo $user_about_short; ?></h3>
                    <p><?php echo $user_about_long; ?></p>
                    <p>My journey in web development started with a curiosity about how websites work, and it has evolved into a career that I truly love. I believe in continuous learning and staying updated with the latest technologies.</p>
                    <div class="about-stats">
                        <div class="stat-item">
                            <h4 class="counter" data-target="<?php echo $projects_done; ?>">0</h4>
                            <p>Projects Done</p>
                        </div>
                        <div class="stat-item">
                            <h4 class="counter" data-target="<?php echo $happy_clients; ?>">0</h4>
                            <p>Happy Clients</p>
                        </div>
                        <div class="stat-item">
                            <h4 class="counter" data-target="<?php echo $years_experience; ?>">0</h4>
                            <p>Years Experience</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section class="services" id="services">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>My Services</h2>
                <p>What I can do for you</p>
            </div>
            <div class="row g-4">
                <?php 
                $icons = ['bi-code-slash', 'bi-palette', 'bi-phone', 'bi-cart3', 'bi-graph-up', 'bi-cloud'];
                foreach ($services as $index => $service): 
                    $icon_class = isset($icons[$index]) ? $icons[$index] : 'bi-star';
                    $service_icon_class = 'service-icon-' . (($index % 6) + 1);
                ?>
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="<?php echo ($index * 100); ?>">
                    <div class="service-card">
                        <div class="service-icon <?php echo $service_icon_class; ?>">
                            <i class="bi <?php echo $icon_class; ?>"></i>
                        </div>
                        <h3><?php echo $service['name']; ?></h3>
                        <p><?php echo $service['description']; ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Skills Section -->
    <section class="skills" id="skills">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>My Skills</h2>
                <p>Technologies and tools I work with</p>
            </div>
            <div class="row">
                <?php 
                $left_skills = array_slice($skills, 0, ceil(count($skills) / 2));
                $right_skills = array_slice($skills, ceil(count($skills) / 2));
                ?>
                <div class="col-lg-6" data-aos="fade-right">
                    <?php foreach ($left_skills as $skill): ?>
                    <div class="skill-item">
                        <div class="skill-header">
                            <h4><?php echo $skill['name']; ?></h4>
                            <span><?php echo $skill['percentage']; ?>%</span>
                        </div>
                        <div class="progress">
                            <div class="progress-bar" style="width: <?php echo $skill['percentage']; ?>%"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="col-lg-6" data-aos="fade-left">
                    <?php foreach ($right_skills as $skill): ?>
                    <div class="skill-item">
                        <div class="skill-header">
                            <h4><?php echo $skill['name']; ?></h4>
                            <span><?php echo $skill['percentage']; ?>%</span>
                        </div>
                        <div class="progress">
                            <div class="progress-bar" style="width: <?php echo $skill['percentage']; ?>%"></div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </section>

    <!-- Portfolio Section -->
    <section class="portfolio" id="portfolio">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>My Portfolio</h2>
                <p>Check out my recent work</p>
            </div>
            <div class="portfolio-filter" data-aos="fade-up">
                <button class="filter-btn active" data-filter="all">All</button>
                <?php foreach ($categories as $category): ?>
                <button class="filter-btn" data-filter="<?php echo $category['slug']; ?>"><?php echo $category['name']; ?></button>
                <?php endforeach; ?>
            </div>
            <div class="portfolio-grid">
                <?php foreach ($projects as $index => $project): ?>
                <div class="portfolio-item" data-category="<?php echo $project['category_name'] ? strtolower(str_replace(' ', '-', $project['category_name'])) : 'all'; ?>" data-aos="zoom-in" data-aos-delay="<?php echo ($index * 100); ?>">
                    <img src="<?php echo $project['image'] ?? 'https://via.placeholder.com/600x450'; ?>" alt="<?php echo $project['title']; ?>">
                    <div class="portfolio-overlay">
                        <h3><?php echo $project['title']; ?></h3>
                        <p><?php echo $project['category_name'] ?? 'Project'; ?></p>
                        <div class="links">
                            <?php if ($project['live_link']): ?>
                            <a href="<?php echo $project['live_link']; ?>" target="_blank"><i class="bi bi-link"></i></a>
                            <?php endif; ?>
                            <?php if ($project['github_link']): ?>
                            <a href="<?php echo $project['github_link']; ?>" target="_blank"><i class="bi bi-github"></i></a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Testimonials Section -->
    <section class="testimonials" id="testimonials">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Testimonials</h2>
                <p>What clients say about me</p>
            </div>
            <div class="row g-4">
                <?php foreach ($testimonials as $index => $testimonial): ?>
                <div class="col-md-6 col-lg-4" data-aos="fade-up" data-aos-delay="<?php echo ($index * 100); ?>">
                    <div class="testimonial-card">
                        <div class="testimonial-content">
                            <div class="testimonial-stars">
                                <?php for ($i = 0; $i < $testimonial['rating']; $i++): ?>
                                <i class="bi bi-star-fill"></i>
                                <?php endfor; ?>
                            </div>
                            <p>"<?php echo $testimonial['quote']; ?>"</p>
                            <div class="testimonial-author">
                                <img src="<?php echo $testimonial['client_image'] ?? 'https://via.placeholder.com/100'; ?>" alt="<?php echo $testimonial['client_name']; ?>">
                                <div>
                                    <h4><?php echo $testimonial['client_name']; ?></h4>
                                    <span><?php echo $testimonial['client_title']; ?></span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="contact" id="contact">
        <div class="container">
            <div class="section-title" data-aos="fade-up">
                <h2>Contact Me</h2>
                <p>Let's work together</p>
            </div>
            <div class="contact-info" data-aos="fade-up">
                <div class="contact-item">
                    <i class="bi bi-geo-alt"></i>
                    <h4>Location</h4>
                    <p><?php echo $user_location; ?></p>
                </div>
                <div class="contact-item">
                    <i class="bi bi-envelope"></i>
                    <h4>Email</h4>
                    <p><?php echo $user['email'] ?? 'john.doe@email.com'; ?></p>
                </div>
                <div class="contact-item">
                    <i class="bi bi-phone"></i>
                    <h4>Phone</h4>
                    <p><?php echo $user_phone; ?></p>
                </div>
                <div class="contact-item">
                    <i class="bi bi-clock"></i>
                    <h4>Working Hours</h4>
                    <p><?php echo $user_working_hours; ?></p>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-8" data-aos="fade-up">
                    <form class="contact-form" id="contactForm" method="POST" action="contact_handler.php">
                        <div class="row">
                            <div class="col-md-6">
                                <input type="text" class="form-control" name="name" placeholder="Your Name" required>
                            </div>
                            <div class="col-md-6">
                                <input type="email" class="form-control" name="email" placeholder="Your Email" required>
                            </div>
                        </div>
                        <input type="text" class="form-control" name="subject" placeholder="Subject">
                        <textarea class="form-control" name="message" placeholder="Your Message" required></textarea>
                        <button type="submit" class="btn btn-custom w-100">Send Message</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer>
        <div class="container">
            <div class="footer-content">
                <div class="footer-about">
                    <h3>Portfolio</h3>
                    <p><?php echo $user_description; ?></p>
                    <div class="footer-social">
                        <?php if ($user['facebook_link']): ?><a href="<?php echo $user['facebook_link']; ?>" target="_blank"><i class="bi bi-facebook"></i></a><?php endif; ?>
                        <?php if ($user['twitter_link']): ?><a href="<?php echo $user['twitter_link']; ?>" target="_blank"><i class="bi bi-twitter"></i></a><?php endif; ?>
                        <?php if ($user['instagram_link']): ?><a href="<?php echo $user['instagram_link']; ?>" target="_blank"><i class="bi bi-instagram"></i></a><?php endif; ?>
                        <?php if ($user['linkedin_link']): ?><a href="<?php echo $user['linkedin_link']; ?>" target="_blank"><i class="bi bi-linkedin"></i></a><?php endif; ?>
                        <?php if ($user['github_link']): ?><a href="<?php echo $user['github_link']; ?>" target="_blank"><i class="bi bi-github"></i></a><?php endif; ?>
                    </div>
                </div>
                <div class="footer-links">
                    <h4>Quick Links</h4>
                    <ul>
                        <li><a href="#home">Home</a></li>
                        <li><a href="#about">About</a></li>
                        <li><a href="#services">Services</a></li>
                        <li><a href="#portfolio">Portfolio</a></li>
                        <li><a href="#contact">Contact</a></li>
                    </ul>
                </div>
                <div class="footer-links">
                    <h4>Services</h4>
                    <ul>
                        <?php foreach (array_slice($services, 0, 5) as $service): ?>
                        <li><a href="#services"><?php echo $service['name']; ?></a></li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <div class="footer-links">
                    <h4>Newsletter</h4>
                    <p style="color: #aaa; margin-bottom: 15px;">Subscribe to get latest updates</p>
                    <form method="POST" action="subscribe.php" style="display: flex; gap: 10px;">
                        <input type="email" class="form-control" name="email" placeholder="Your Email" required style="flex: 1;">
                        <button class="btn btn-custom" style="padding: 15px 20px;">
                            <i class="bi bi-send"></i>
                        </button>
                    </form>
                </div>
            </div>
            <div class="footer-bottom">
                <p>&copy; 2024 Portfolio. All Rights Reserved. Designed with <i class="bi bi-heart-fill" style="color: var(--accent-color);"></i> by <?php echo $user_name; ?></p>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <button class="back-to-top" id="backToTop">
        <i class="bi bi-arrow-up"></i>
    </button>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- AOS Animation Library -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    
    <script>
        // Preloader
        window.addEventListener('load', () => {
            const preloader = document.getElementById('preloader');
            setTimeout(() => {
                preloader.classList.add('hidden');
            }, 1000);
        });

        // Initialize AOS
        AOS.init({
            duration: 1000,
            once: true,
            offset: 100
        });

        // Navbar scroll effect
        window.addEventListener('scroll', () => {
            const navbar = document.querySelector('.navbar');
            const backToTop = document.getElementById('backToTop');
            
            if (window.scrollY > 100) {
                navbar.classList.add('scrolled');
                backToTop.classList.add('visible');
            } else {
                navbar.classList.remove('scrolled');
                backToTop.classList.remove('visible');
            }
        });

        // Back to top button
        document.getElementById('backToTop').addEventListener('click', () => {
            window.scrollTo({
                top: 0,
                behavior: 'smooth'
            });
        });

        // Smooth scrolling for navigation links
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const target = document.querySelector(this.getAttribute('href'));
                if (target) {
                    target.scrollIntoView({
                        behavior: 'smooth',
                        block: 'start'
                    });
                    
                    // Close mobile menu after clicking
                    const navbarCollapse = document.querySelector('.navbar-collapse');
                    if (navbarCollapse.classList.contains('show')) {
                        navbarCollapse.classList.remove('show');
                    }
                }
            });
        });

        // Counter animation
        const counters = document.querySelectorAll('.counter');
        const speed = 200;

        const animateCounters = () => {
            counters.forEach(counter => {
                const target = +counter.getAttribute('data-target');
                const count = +counter.innerText;
                const increment = target / speed;

                if (count < target) {
                    counter.innerText = Math.ceil(count + increment);
                    setTimeout(animateCounters, 10);
                } else {
                    counter.innerText = target + '+';
                }
            });
        };

        // Trigger counter animation when about section is visible
        const aboutSection = document.querySelector('.about');
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateCounters();
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.5 });

        observer.observe(aboutSection);

        // Portfolio filter
        const filterBtns = document.querySelectorAll('.filter-btn');
        const portfolioItems = document.querySelectorAll('.portfolio-item');

        filterBtns.forEach(btn => {
            btn.addEventListener('click', () => {
                // Remove active class from all buttons
                filterBtns.forEach(b => b.classList.remove('active'));
                // Add active class to clicked button
                btn.classList.add('active');
                
                const filter = btn.getAttribute('data-filter');
                
                portfolioItems.forEach(item => {
                    if (filter === 'all' || item.getAttribute('data-category') === filter) {
                        item.style.display = 'block';
                        item.style.animation = 'zoomIn 0.5s ease';
                    } else {
                        item.style.display = 'none';
                    }
                });
            });
        });

        // Contact form submission
        document.getElementById('contactForm').addEventListener('submit', (e) => {
            e.preventDefault();
            
            const formData = new FormData(e.target);
            
            fetch('contact_handler.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message);
                    e.target.reset();
                } else {
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => console.error('Error:', error));
        });

        // Add zoomIn animation keyframes
        const style = document.createElement('style');
        style.textContent = `
            @keyframes zoomIn {
                from {
                    opacity: 0;
                    transform: scale(0.9);
                }
                to {
                    opacity: 1;
                    transform: scale(1);
                }
            }
        `;
        document.head.appendChild(style);

        // Parallax effect for hero shapes
        window.addEventListener('scroll', () => {
            const scrolled = window.scrollY;
            const shapes = document.querySelectorAll('.shape');
            
            shapes.forEach((shape, index) => {
                const speed = (index + 1) * 0.5;
                shape.style.transform = `translateY(${scrolled * speed}px)`;
            });
        });
    </script>
</body>
</html>
