<?php
require_once '../config.php';

if (!isLoggedIn()) {
    redirect('../admin_login.php');
}

$user = getUserData();
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name'] ?? '');
    $email = sanitize($_POST['email'] ?? '');
    $title = sanitize($_POST['title'] ?? '');
    $description = sanitize($_POST['description'] ?? '');
    $about_short = sanitize($_POST['about_short'] ?? '');
    $about_long = sanitize($_POST['about_long'] ?? '');
    $location = sanitize($_POST['location'] ?? '');
    $phone = sanitize($_POST['phone'] ?? '');
    $working_hours = sanitize($_POST['working_hours'] ?? '');
    $projects_done = (int)$_POST['projects_done'] ?? 0;
    $happy_clients = (int)$_POST['happy_clients'] ?? 0;
    $years_experience = (int)$_POST['years_experience'] ?? 0;
    $facebook_link = sanitize($_POST['facebook_link'] ?? '');
    $twitter_link = sanitize($_POST['twitter_link'] ?? '');
    $instagram_link = sanitize($_POST['instagram_link'] ?? '');
    $linkedin_link = sanitize($_POST['linkedin_link'] ?? '');
    $github_link = sanitize($_POST['github_link'] ?? '');
    
    $user_id = $_SESSION['user_id'];
    
    $query = "UPDATE users SET 
              name = '$name',
              email = '$email',
              title = '$title',
              description = '$description',
              about_content_short = '$about_short',
              about_content_long = '$about_long',
              location = '$location',
              phone = '$phone',
              working_hours = '$working_hours',
              projects_done = $projects_done,
              happy_clients = $happy_clients,
              years_experience = $years_experience,
              facebook_link = '$facebook_link',
              twitter_link = '$twitter_link',
              instagram_link = '$instagram_link',
              linkedin_link = '$linkedin_link',
              github_link = '$github_link'
              WHERE id = $user_id";
    
    if ($conn->query($query) === TRUE) {
        $success = 'Profile updated successfully!';
        $_SESSION['user_name'] = $name;
        $_SESSION['user_email'] = $email;
        $user = getUserData();
    } else {
        $error = 'Error: ' . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        body {
            background: #f8f9fa;
            font-family: 'Poppins', sans-serif;
        }
        
        .sidebar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            color: white;
        }
        
        .sidebar h3 {
            margin-bottom: 30px;
            font-weight: 700;
        }
        
        .sidebar ul {
            list-style: none;
        }
        
        .sidebar ul li {
            margin-bottom: 15px;
        }
        
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .sidebar ul li a:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        
        .sidebar ul li a.active {
            background: rgba(255, 255, 255, 0.3);
        }
        
        .main-content {
            margin-left: 250px;
            padding: 30px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .header h1 {
            margin: 0;
            font-size: 1.8rem;
            color: #2d3436;
        }
        
        .content-section {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            font-weight: 600;
            margin-bottom: 8px;
            color: #2d3436;
        }
        
        .form-control {
            border-radius: 8px;
            border: 1px solid #ddd;
            padding: 12px 15px;
        }
        
        .form-control:focus {
            border-color: #667eea;
            box-shadow: 0 0 0 0.2rem rgba(102, 126, 234, 0.25);
        }
        
        .btn-submit {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 12px 30px;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
            color: white;
        }
        
        .alert {
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h3><i class="bi bi-speedometer2"></i> Admin Panel</h3>
        <ul>
            <li><a href="dashboard.php"><i class="bi bi-house"></i> Dashboard</a></li>
            <li><a href="profile.php" class="active"><i class="bi bi-person"></i> Profile</a></li>
            <li><a href="services.php"><i class="bi bi-briefcase"></i> Services</a></li>
            <li><a href="skills.php"><i class="bi bi-star"></i> Skills</a></li>
            <li><a href="projects.php"><i class="bi bi-folder"></i> Projects</a></li>
            <li><a href="testimonials.php"><i class="bi bi-chat-quote"></i> Testimonials</a></li>
            <li><a href="messages.php"><i class="bi bi-envelope"></i> Messages</a></li>
            <li><a href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <h1>Edit Profile</h1>
        </div>
        
        <?php if (!empty($success)): ?>
            <div class="alert alert-success" role="alert">
                <i class="bi bi-check-circle"></i> <?php echo $success; ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($error)): ?>
            <div class="alert alert-danger" role="alert">
                <i class="bi bi-exclamation-circle"></i> <?php echo $error; ?>
            </div>
        <?php endif; ?>
        
        <div class="content-section">
            <form method="POST" action="">
                <h3 class="mb-4">Personal Information</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?php echo $user['name'] ?? ''; ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="email" name="email" value="<?php echo $user['email'] ?? ''; ?>" required>
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="title" class="form-label">Professional Title</label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo $user['title'] ?? ''; ?>" placeholder="e.g., Web Developer & Designer">
                    </div>
                    
                    <div class="form-group">
                        <label for="location" class="form-label">Location</label>
                        <input type="text" class="form-control" id="location" name="location" value="<?php echo $user['location'] ?? ''; ?>" placeholder="e.g., New York, NY">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="phone" class="form-label">Phone Number</label>
                        <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo $user['phone'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="working_hours" class="form-label">Working Hours</label>
                        <input type="text" class="form-control" id="working_hours" name="working_hours" value="<?php echo $user['working_hours'] ?? ''; ?>" placeholder="e.g., Mon - Fri: 9AM - 6PM">
                    </div>
                </div>
                
                <hr class="my-4">
                
                <h3 class="mb-4">About You</h3>
                
                <div class="form-group">
                    <label for="description" class="form-label">Short Description</label>
                    <textarea class="form-control" id="description" name="description" rows="3" placeholder="Brief description for hero section"><?php echo $user['description'] ?? ''; ?></textarea>
                </div>
                
                <div class="form-group">
                    <label for="about_short" class="form-label">About Section Title</label>
                    <input type="text" class="form-control" id="about_short" name="about_short" value="<?php echo $user['about_content_short'] ?? ''; ?>">
                </div>
                
                <div class="form-group">
                    <label for="about_long" class="form-label">About Section Description</label>
                    <textarea class="form-control" id="about_long" name="about_long" rows="4" placeholder="Detailed about section content"><?php echo $user['about_content_long'] ?? ''; ?></textarea>
                </div>
                
                <hr class="my-4">
                
                <h3 class="mb-4">Statistics</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="projects_done" class="form-label">Projects Done</label>
                        <input type="number" class="form-control" id="projects_done" name="projects_done" value="<?php echo $user['projects_done'] ?? 0; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="happy_clients" class="form-label">Happy Clients</label>
                        <input type="number" class="form-control" id="happy_clients" name="happy_clients" value="<?php echo $user['happy_clients'] ?? 0; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="years_experience" class="form-label">Years of Experience</label>
                        <input type="number" class="form-control" id="years_experience" name="years_experience" value="<?php echo $user['years_experience'] ?? 0; ?>">
                    </div>
                </div>
                
                <hr class="my-4">
                
                <h3 class="mb-4">Social Links</h3>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="facebook_link" class="form-label">Facebook URL</label>
                        <input type="url" class="form-control" id="facebook_link" name="facebook_link" value="<?php echo $user['facebook_link'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="twitter_link" class="form-label">Twitter URL</label>
                        <input type="url" class="form-control" id="twitter_link" name="twitter_link" value="<?php echo $user['twitter_link'] ?? ''; ?>">
                    </div>
                </div>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="instagram_link" class="form-label">Instagram URL</label>
                        <input type="url" class="form-control" id="instagram_link" name="instagram_link" value="<?php echo $user['instagram_link'] ?? ''; ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="linkedin_link" class="form-label">LinkedIn URL</label>
                        <input type="url" class="form-control" id="linkedin_link" name="linkedin_link" value="<?php echo $user['linkedin_link'] ?? ''; ?>">
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="github_link" class="form-label">GitHub URL</label>
                    <input type="url" class="form-control" id="github_link" name="github_link" value="<?php echo $user['github_link'] ?? ''; ?>">
                </div>
                
                <hr class="my-4">
                
                <button type="submit" class="btn btn-submit">
                    <i class="bi bi-check-circle"></i> Save Changes
                </button>
            </form>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
