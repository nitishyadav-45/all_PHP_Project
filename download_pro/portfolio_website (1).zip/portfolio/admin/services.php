<?php require_once '../config.php'; if(!isLoggedIn()) redirect('../admin_login.php'); ?>
<!DOCTYPE html>
<html>
<head><title>Services Management</title></head>
<body><h1>Services Management Placeholder</h1><p>This page will allow adding/editing/deleting services.</p><a href="dashboard.php">Back to Dashboard</a></body>
</html>
