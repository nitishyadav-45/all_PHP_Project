<?php
require_once '../config.php';

// Check if user is logged in
if (!isLoggedIn()) {
    redirect('../admin_login.php');
}

$user = getUserData();
$services = getAllServices();
$skills = getAllSkills();
$projects = getAllProjects();
$testimonials = getAllTestimonials();

// Get contact messages count
$messages_query = "SELECT COUNT(*) as count FROM contact_messages";
$messages_result = $conn->query($messages_query);
$messages_count = $messages_result->fetch_assoc()['count'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Portfolio</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            background: #f8f9fa;
            font-family: 'Poppins', sans-serif;
        }
        
        .sidebar {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
            padding: 20px;
            position: fixed;
            left: 0;
            top: 0;
            width: 250px;
            color: white;
        }
        
        .sidebar h3 {
            margin-bottom: 30px;
            font-weight: 700;
        }
        
        .sidebar ul {
            list-style: none;
        }
        
        .sidebar ul li {
            margin-bottom: 15px;
        }
        
        .sidebar ul li a {
            color: white;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 15px;
            border-radius: 8px;
            transition: all 0.3s ease;
        }
        
        .sidebar ul li a:hover {
            background: rgba(255, 255, 255, 0.2);
        }
        
        .sidebar ul li a.active {
            background: rgba(255, 255, 255, 0.3);
        }
        
        .main-content {
            margin-left: 250px;
            padding: 30px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
        
        .header h1 {
            margin: 0;
            font-size: 1.8rem;
            color: #2d3436;
        }
        
        .logout-btn {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .logout-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        
        .stat-card h3 {
            font-size: 2rem;
            color: #667eea;
            margin-bottom: 10px;
        }
        
        .stat-card p {
            color: #aaa;
            margin: 0;
        }
        
        .content-section {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 30px;
        }
        
        .content-section h2 {
            margin-bottom: 20px;
            color: #2d3436;
            font-weight: 700;
        }
        
        .btn-add {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 8px;
            cursor: pointer;
            margin-bottom: 20px;
            transition: all 0.3s ease;
        }
        
        .btn-add:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
            color: white;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        table thead {
            background: #f8f9fa;
        }
        
        table th {
            padding: 15px;
            text-align: left;
            color: #2d3436;
            font-weight: 600;
            border-bottom: 2px solid #ddd;
        }
        
        table td {
            padding: 15px;
            border-bottom: 1px solid #ddd;
        }
        
        .action-btn {
            padding: 5px 10px;
            margin-right: 5px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 0.85rem;
            transition: all 0.3s ease;
        }
        
        .btn-edit {
            background: #4facfe;
            color: white;
        }
        
        .btn-delete {
            background: #ff6b6b;
            color: white;
        }
        
        .action-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        }
        
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <h3><i class="bi bi-speedometer2"></i> Admin Panel</h3>
        <ul>
            <li><a href="dashboard.php" class="active"><i class="bi bi-house"></i> Dashboard</a></li>
            <li><a href="profile.php"><i class="bi bi-person"></i> Profile</a></li>
            <li><a href="services.php"><i class="bi bi-briefcase"></i> Services</a></li>
            <li><a href="skills.php"><i class="bi bi-star"></i> Skills</a></li>
            <li><a href="projects.php"><i class="bi bi-folder"></i> Projects</a></li>
            <li><a href="testimonials.php"><i class="bi bi-chat-quote"></i> Testimonials</a></li>
            <li><a href="messages.php"><i class="bi bi-envelope"></i> Messages</a></li>
            <li><a href="logout.php"><i class="bi bi-box-arrow-right"></i> Logout</a></li>
        </ul>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <div>
                <h1>Welcome, <?php echo $user['name']; ?>!</h1>
                <p style="color: #aaa; margin: 0;">Dashboard Overview</p>
            </div>
            <a href="logout.php" class="logout-btn">Logout</a>
        </div>
        
        <!-- Statistics -->
        <div class="stats-grid">
            <div class="stat-card">
                <h3><?php echo count($projects); ?></h3>
                <p>Total Projects</p>
            </div>
            <div class="stat-card">
                <h3><?php echo count($services); ?></h3>
                <p>Services</p>
            </div>
            <div class="stat-card">
                <h3><?php echo count($skills); ?></h3>
                <p>Skills</p>
            </div>
            <div class="stat-card">
                <h3><?php echo $messages_count; ?></h3>
                <p>Messages</p>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="content-section">
            <h2>Quick Actions</h2>
            <div class="row">
                <div class="col-md-3 mb-3">
                    <a href="profile.php" class="btn btn-add w-100">
                        <i class="bi bi-pencil"></i> Edit Profile
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="projects.php" class="btn btn-add w-100">
                        <i class="bi bi-plus"></i> Add Project
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="services.php" class="btn btn-add w-100">
                        <i class="bi bi-plus"></i> Add Service
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="messages.php" class="btn btn-add w-100">
                        <i class="bi bi-envelope"></i> View Messages
                    </a>
                </div>
            </div>
        </div>
        
        <!-- Recent Projects -->
        <div class="content-section">
            <h2>Recent Projects</h2>
            <?php if (count($projects) > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Category</th>
                            <th>Created</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach (array_slice($projects, 0, 5) as $project): ?>
                            <tr>
                                <td><?php echo $project['title']; ?></td>
                                <td><?php echo $project['category_name'] ?? 'Uncategorized'; ?></td>
                                <td><?php echo date('M d, Y', strtotime($project['created_at'])); ?></td>
                                <td>
                                    <button class="action-btn btn-edit">Edit</button>
                                    <button class="action-btn btn-delete">Delete</button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p style="color: #aaa;">No projects yet. <a href="projects.php">Add your first project</a></p>
            <?php endif; ?>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
