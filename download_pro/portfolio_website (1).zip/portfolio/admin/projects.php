<?php require_once '../config.php'; if(!isLoggedIn()) redirect('../admin_login.php'); ?>
<!DOCTYPE html>
<html>
<head><title>Projects Management</title></head>
<body><h1>Projects Management Placeholder</h1><p>This page will allow adding/editing/deleting projects.</p><a href="dashboard.php">Back to Dashboard</a></body>
</html>
