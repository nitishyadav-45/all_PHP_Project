<?php
require_once '../../includes/config.php';
require_once '../../includes/auth.php';
require_once '../../includes/functions.php';
checkLogin();

if (isset($_GET['read'])) {
    $id = $_GET['read'];
    $stmt = $pdo->prepare("UPDATE contacts SET is_read = 1 WHERE id = ?");
    $stmt->execute([$id]);
}

$stmt = $pdo->query("SELECT * FROM contacts ORDER BY created_at DESC");
$messages = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Messages | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="d-flex justify-content-between mb-4">
            <h3>Messages</h3>
            <a href="../dashboard.php" class="btn btn-secondary">Back</a>
        </div>

        <div class="card">
            <div class="card-body">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>From</th>
                            <th>Subject</th>
                            <th>Status</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($messages as $msg): ?>
                        <tr class="<?php echo $msg['is_read'] ? '' : 'table-warning'; ?>">
                            <td><?php echo date('d M Y', strtotime($msg['created_at'])); ?></td>
                            <td><?php echo $msg['name']; ?> (<?php echo $msg['email']; ?>)</td>
                            <td><?php echo $msg['subject']; ?></td>
                            <td><?php echo $msg['is_read'] ? 'Read' : 'New'; ?></td>
                            <td>
                                <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#msgModal<?php echo $msg['id']; ?>" onclick="window.location.href='?read=<?php echo $msg['id']; ?>'">View</button>
                                
                                <!-- Modal -->
                                <div class="modal fade" id="msgModal<?php echo $msg['id']; ?>" tabindex="-1">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title"><?php echo $msg['subject']; ?></h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p><strong>From:</strong> <?php echo $msg['name']; ?> (<?php echo $msg['email']; ?>)</p>
                                                <hr>
                                                <p><?php echo nl2br($msg['message']); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
