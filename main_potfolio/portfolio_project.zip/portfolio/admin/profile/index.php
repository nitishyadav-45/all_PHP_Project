<?php
require_once '../../includes/config.php';
require_once '../../includes/auth.php';
require_once '../../includes/functions.php';
checkLogin();

$profile = getProfile($pdo);
$message = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = sanitize($_POST['name']);
    $title = sanitize($_POST['title']);
    $about_me = $_POST['about_me'];
    $email = sanitize($_POST['email']);
    $phone = sanitize($_POST['phone']);
    $address = sanitize($_POST['address']);

    $stmt = $pdo->prepare("UPDATE profile SET name = ?, title = ?, about_me = ?, email = ?, phone = ?, address = ? WHERE id = 1");
    if ($stmt->execute([$name, $title, $about_me, $email, $phone, $address])) {
        $message = '<div class="alert alert-success">Profile updated successfully!</div>';
        $profile = getProfile($pdo);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Profile | Admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white d-flex justify-content-between">
                        <h5 class="mb-0">Edit Profile</h5>
                        <a href="../dashboard.php" class="btn btn-sm btn-light">Back to Dashboard</a>
                    </div>
                    <div class="card-body">
                        <?php echo $message; ?>
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Full Name</label>
                                <input type="text" name="name" class="form-control" value="<?php echo $profile['name']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Professional Title</label>
                                <input type="text" name="title" class="form-control" value="<?php echo $profile['title']; ?>" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">About Me</label>
                                <textarea name="about_me" class="form-control" rows="5" required><?php echo $profile['about_me']; ?></textarea>
                            </div>
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Email</label>
                                    <input type="email" name="email" class="form-control" value="<?php echo $profile['email']; ?>">
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label">Phone</label>
                                    <input type="text" name="phone" class="form-control" value="<?php echo $profile['phone']; ?>">
                                </div>
                            </div>
                            <div class="mb-4">
                                <label class="form-label">Address</label>
                                <input type="text" name="address" class="form-control" value="<?php echo $profile['address']; ?>">
                            </div>
                            <button type="submit" class="btn btn-primary">Update Profile</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
